import { type ActionDispatch } from "react";
import type { DeckMode } from "../deck/mode";
import type { DeckAction } from "../deck/reducer";
/** Listens on the window rather than a deck element, so a presenter never has to click the deck first. */
export declare function useKeyboardNavigation(dispatch: ActionDispatch<[action: DeckAction]>, mode: DeckMode): void;
