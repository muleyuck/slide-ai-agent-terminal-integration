export declare const MIN_SIDEBAR_WIDTH = 120;
export declare const MAX_SIDEBAR_WIDTH = 480;
export declare const DEFAULT_SIDEBAR_WIDTH = 240;
/** Takes `unknown` because one caller is a pointer position and the other is whatever was left in storage. */
export declare function clampSidebarWidth(value: unknown): number;
