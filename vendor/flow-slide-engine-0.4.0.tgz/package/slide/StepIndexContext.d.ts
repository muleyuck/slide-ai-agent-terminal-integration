/**
 * Which step of its slide a `<Step>` is.
 *
 * Supplied by the slide as it walks its markup, through context rather than a prop, so the number stays out of
 * `Step`'s public shape.
 */
export declare const StepIndexContext: import("react").Context<number | null>;
