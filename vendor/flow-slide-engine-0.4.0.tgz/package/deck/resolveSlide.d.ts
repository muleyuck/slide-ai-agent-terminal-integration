/**
 * Resolve a slide position against the number of slides the deck holds.
 *
 * The stored position is not kept within range — the deck can lose slides while
 * sitting on one of them — so readers clamp at the point of use, the same way
 * they resolve a step.
 */
export declare function resolveSlide(slide: number, slideCount: number): number;
