import { type ReactNode } from "react";
export type StageProps = {
    /** Logical stage width in pixels. */
    width: number;
    /** Logical stage height in pixels. */
    height: number;
    children?: ReactNode;
};
/**
 * A fixed-size stage, scaled to fill whatever space it is given.
 *
 * Slides are authored against the logical size, so a deck looks the same on a laptop, on a projector, and in an export.
 * The scale is published as the `--fs-state-scale` custom property so slide content can react to it.
 */
export declare function Stage({ width, height, children }: StageProps): import("react").JSX.Element;
