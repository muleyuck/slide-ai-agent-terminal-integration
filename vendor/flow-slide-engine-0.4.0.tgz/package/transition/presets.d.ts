import type { Transition } from "./types";
/** Change slides instantly. */
export declare const none: Transition;
/** Cross-fade between slides. */
export declare const fade: Transition;
/** Push the slides sideways, in the direction the deck is moving. */
export declare const slideHorizontal: Transition;
