/** Which way through the deck a change is going. */
export type TransitionDirection = "forward" | "backward";
/** The keyframes to run, chosen by the way the deck is moving. */
export type DirectionalKeyframes = Readonly<Record<TransitionDirection, string>>;
/**
 * How the deck moves from one slide to the next.
 *
 * `enter` and `leave` name `@keyframes` rules, so a transition of your own is this value plus the keyframes it names,
 * with no selector to match. `durationMs` reaches those rules as `--fs-state-duration` and also tells the engine how long to
 * keep the outgoing slide on stage, so the two cannot disagree.
 */
export type Transition = {
    readonly durationMs: number;
    readonly enter: DirectionalKeyframes;
    readonly leave: DirectionalKeyframes;
};
