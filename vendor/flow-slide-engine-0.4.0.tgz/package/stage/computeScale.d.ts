export type Size = {
    width: number;
    height: number;
};
/**
 * The factor that fits `stage` inside `viewport` without cropping or distortion.
 *
 * 0 for a degenerate stage or an unmeasured viewport, so nothing is painted at a wrong size before the first
 * measurement lands.
 */
export declare function computeScale(stage: Size, viewport: Size): number;
