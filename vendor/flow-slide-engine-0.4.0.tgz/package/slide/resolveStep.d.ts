/**
 * A step position within a slide.
 *
 * `"last"` means "the final step of whichever slide this is". Stepping backwards has to name a slide's last step before
 * that slide is mounted, so its count is not yet known; the sentinel is resolved once the slide reports.
 */
export type StepIndex = number | "last";
/** A slide with `stepCount` steps has `stepCount + 1` states: state 0 reveals nothing, each next one reveals one more. */
export declare function resolveStep(step: StepIndex, stepCount: number): number;
