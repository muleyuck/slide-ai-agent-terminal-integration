import { type StepIndex } from "../slide/resolveStep";
import type { DeckMode } from "./mode";
export type DeckPosition = {
    slide: number;
    step: StepIndex;
};
export type DeckState = {
    /** Which presentation is on screen. Independent of where the deck is. */
    mode: DeckMode;
    /**
     * Where the deck currently is. Neither field is kept in range: `step` may be the `"last"` sentinel or point past a
     * slide that has not reported its count, and `slide` may point past a deck that has since lost slides. Read through
     * `resolveSlide` and `resolveStep`.
     */
    position: DeckPosition;
    /** Steps in the slide on screen. 0 means "not reported yet", from the move onto a slide until it mounts. */
    stepCount: number;
};
export type DeckAction = {
    type: "next";
} | {
    type: "prev";
} | {
    type: "nextSlide";
} | {
    type: "prevSlide";
} | {
    type: "first";
} | {
    type: "last";
} | {
    type: "goTo";
    position: DeckPosition;
} | {
    type: "setStepCount";
    count: number;
} | {
    type: "setMode";
    mode: DeckMode;
};
/** `slideCount` is derived from the deck's children, so it is passed in rather than kept in state and synced. */
export declare function deckReducer(state: DeckState, action: DeckAction, slideCount: number): DeckState;
