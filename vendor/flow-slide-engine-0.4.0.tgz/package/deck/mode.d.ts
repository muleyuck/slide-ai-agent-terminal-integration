/** Which of the deck's four presentations is on screen. */
export type DeckMode = "present" | "overview" | "browse" | "print";
/** Null rather than a default, so the caller decides what an unreadable URL means. */
export declare function parseMode(segment: string | undefined): DeckMode | null;
