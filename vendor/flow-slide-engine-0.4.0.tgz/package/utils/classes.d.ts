/** Every engine element carries a class the stylesheet and themes rely on, so an author's class is added, not swapped in. */
export declare function classes(...names: (string | undefined)[]): string;
