import type { ViewProps } from "./ViewProps";
/** The whole deck at a glance, and nothing else. */
export declare function OverviewView({ slides, width, height }: ViewProps): import("react").JSX.Element;
