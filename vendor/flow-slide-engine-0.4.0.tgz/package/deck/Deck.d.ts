import { type ReactNode } from "react";
import type { Transition } from "../transition/types";
export type DeckProps = {
    children?: ReactNode;
    /** Logical stage width in pixels. */
    width?: number;
    /** Logical stage height in pixels. */
    height?: number;
    /** Keep the position and the mode in the URL hash, and open at what it names. */
    url?: boolean;
    /** How the deck moves between slides. A slide may name its own instead. */
    transition?: Transition;
};
/**
 * The root of a presentation. Each top-level child is one slide.
 *
 * In `present` only the slide on screen is mounted, so a deck stays cheap however many slides it holds; the other modes
 * show every slide at once and pay for it knowingly.
 */
export declare function Deck({ children, width, height, url, transition, }: DeckProps): import("react").JSX.Element;
