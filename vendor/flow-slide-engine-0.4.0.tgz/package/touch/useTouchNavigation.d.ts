import { type ActionDispatch, type RefObject } from "react";
import type { DeckMode } from "../deck/mode";
import type { DeckAction } from "../deck/reducer";
/**
 * Move through the deck by swiping.
 *
 * Listens on the deck rather than the window, unlike the keyboard: a key press has to reach a presenter who never
 * clicked the deck, while a swipe that landed outside the deck was not aimed at it.
 *
 * Only in `present`. The other modes are scroll surfaces, and each already offers every slide to a tap.
 */
export declare function useTouchNavigation(deckRef: RefObject<HTMLElement | null>, dispatch: ActionDispatch<[action: DeckAction]>, mode: DeckMode): void;
