import { type ActionDispatch } from "react";
import type { DeckMode } from "../deck/mode";
import type { DeckAction } from "../deck/reducer";
import { type HashState } from "./hash";
/** What the current URL names, for seeding a deck as it opens. */
export declare function readHash(): HashState;
type HashSync = {
    enabled: boolean;
    mode: DeckMode;
    position: {
        slide: number;
        step: number;
    };
    dispatch: ActionDispatch<[action: DeckAction]>;
};
/** Keep the deck and the URL hash in step. The deck leads, so a reload or a shared link lands where it left off. */
export declare function useHashSync({ enabled, mode, position, dispatch }: HashSync): void;
export {};
