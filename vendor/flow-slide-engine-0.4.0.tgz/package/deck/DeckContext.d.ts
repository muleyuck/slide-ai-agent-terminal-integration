import { type ActionDispatch } from "react";
import type { DeckAction, DeckState } from "./reducer";
export type DeckContextValue = {
    state: DeckState;
    /** Derived from the deck's children, so it is carried alongside the state. */
    slideCount: number;
    dispatch: ActionDispatch<[action: DeckAction]>;
};
/** Null outside a `<Deck>`, so reading it can say so rather than hand back a plausible-looking empty deck. */
export declare const DeckContext: import("react").Context<DeckContextValue | null>;
/** For a deck that is shown rather than driven — a slide on its way out, a thumbnail. */
export declare const IGNORE_DISPATCH: DeckContextValue["dispatch"];
