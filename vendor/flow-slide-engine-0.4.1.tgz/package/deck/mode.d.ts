/** Which of the deck's four presentations is on screen. */
export type DeckMode = "present" | "overview" | "browse" | "print";
/** Null rather than a default, so the caller decides what an unreadable URL means. */
export declare function parseMode(segment: string | undefined): DeckMode | null;
/**
 * Whether this mode reveals a slide one step at a time.
 *
 * Only `present` does; the others show a slide whole, so a move through them is a move to another slide. Every input
 * asks here rather than naming `present` itself, so what a key press does and what a slide's own control does cannot
 * drift apart.
 */
export declare function revealsSteps(mode: DeckMode): boolean;
