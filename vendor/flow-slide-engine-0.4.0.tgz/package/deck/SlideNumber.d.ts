/**
 * Where you are in the deck, written once rather than on every slide.
 *
 * Only where a single slide is being shown. A page carries no number of the engine's: the browser's print dialog adds
 * its own, and two sets would be one too many.
 */
export declare function SlideNumber(): import("react").JSX.Element;
