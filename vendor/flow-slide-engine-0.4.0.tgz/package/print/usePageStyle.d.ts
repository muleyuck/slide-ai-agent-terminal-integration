/**
 * Make the printed page the same shape as the stage.
 *
 * `@page` cannot be set from an element's style, and a literal size is the only form browsers agree on — a custom
 * property is not read here. reveal.js does the same.
 */
export declare function usePageStyle(width: number, height: number): void;
