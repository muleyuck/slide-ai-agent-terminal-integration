/**
 * The sidebar's width, remembered across reloads.
 *
 * One key for the origin rather than one per deck: the width is a setting for the screen, not a property of a talk.
 */
export declare function useSidebarWidth(): [number, (width: number) => void];
