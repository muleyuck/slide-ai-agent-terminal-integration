/**
 * How far through the deck you are, as a bar along the foot of the stage.
 *
 * Counted in slides rather than steps: only the slide on screen ever reports how many steps it holds, so a deck's total
 * is not a number the engine has. Published as a custom property, the way the stage publishes its scale, so the fill is
 * the stylesheet's to draw.
 */
export declare function Progress(): import("react").JSX.Element;
