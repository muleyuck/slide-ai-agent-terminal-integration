import type { ComponentPropsWithoutRef } from "react";
export type TitleProps = ComponentPropsWithoutRef<"h1">;
/**
 * The heading of a slide.
 *
 * A heading rather than large text, so a deck read out or exported still has structure. Sized by `--fs-title-size`.
 */
export declare function Title({ children, className, ...rest }: TitleProps): import("react").JSX.Element;
