import type { ViewProps } from "./ViewProps";
/** One slide at a time, which is what a deck is for. */
export declare function PresentView({ slides, width, height, transition }: ViewProps): import("react").JSX.Element;
