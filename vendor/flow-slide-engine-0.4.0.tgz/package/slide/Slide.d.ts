import { type ComponentPropsWithoutRef } from "react";
import type { Transition } from "../transition/types";
export type SlideProps = ComponentPropsWithoutRef<"div"> & {
    /**
     * How the deck moves onto this slide, overriding the deck's own choice.
     *
     * Read by the deck from the markup rather than used here: a change involves two slides, and only the deck knows one
     * is happening.
     */
    transition?: Transition;
};
/** One slide of a deck. */
export declare function Slide({ children, className, transition: _readByTheDeck, ...rest }: SlideProps): import("react").JSX.Element;
