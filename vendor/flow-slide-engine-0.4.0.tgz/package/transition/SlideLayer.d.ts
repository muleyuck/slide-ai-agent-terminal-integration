import type { ReactNode } from "react";
import type { Transition, TransitionDirection } from "./types";
/** Where a layer is in the change taking place around it. */
export type TransitionPhase = "settled" | "enter" | "leave";
type SlideLayerProps = {
    transition: Transition;
    phase: TransitionPhase;
    direction: TransitionDirection;
    children?: ReactNode;
};
/**
 * One slide's place on the stage during a change. Layers overlap, so the slide arriving and the one leaving animate
 * against each other rather than one after the other.
 */
export declare function SlideLayer({ transition, phase, direction, children }: SlideLayerProps): import("react").JSX.Element;
export {};
