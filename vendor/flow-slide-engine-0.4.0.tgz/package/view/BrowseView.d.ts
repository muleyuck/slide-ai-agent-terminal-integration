import type { ViewProps } from "./ViewProps";
/**
 * The list beside the slide, for finding your way around a long deck.
 *
 * The slide is `PresentView` itself, not a second rendering of it, so it transitions and behaves exactly as on its own.
 */
export declare function BrowseView(props: ViewProps): import("react").JSX.Element;
