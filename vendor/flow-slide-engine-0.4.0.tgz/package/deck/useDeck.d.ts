import type { DeckMode } from "./mode";
/** What a slide can read and do about the deck it sits in. */
export type DeckApi = {
    /** Which presentation is on screen. */
    mode: DeckMode;
    setMode: (mode: DeckMode) => void;
    /** 0-origin index of the slide on screen. */
    slide: number;
    slideCount: number;
    /** 0-origin step within the current slide; 0 reveals nothing. */
    step: number;
    stepCount: number;
    next: () => void;
    prev: () => void;
    goTo: (position: {
        slide: number;
        step?: number;
    }) => void;
};
export declare function useDeck(): DeckApi;
