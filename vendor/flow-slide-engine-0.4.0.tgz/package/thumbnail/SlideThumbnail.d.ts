import type { ReactNode } from "react";
import type { DeckMode } from "../deck/mode";
type SlideThumbnailProps = {
    slide: ReactNode;
    /** 0-origin, shown to the reader as 1-origin. */
    index: number;
    slideCount: number;
    mode: DeckMode;
    width: number;
    height: number;
    current: boolean;
    onSelect: () => void;
};
/**
 * One slide, small, as a picture of itself.
 *
 * The frozen provider encloses only the `Stage` and the slide within it, so the slide resolves its steps against its
 * own markup and its `setStepCount` report lands on the no-op dispatch instead of reaching the running deck.
 */
export declare function SlideThumbnail({ slide, index, slideCount, mode, width, height, current, onSelect, }: SlideThumbnailProps): import("react").JSX.Element;
export {};
