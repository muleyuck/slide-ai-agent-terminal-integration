import type { DeckState } from "../deck/reducer";
import type { Transition, TransitionDirection } from "./types";
/** The slide on its way out, and the state it was showing when it left. */
export type OutgoingSlide = {
    slide: number;
    /** The state before the change; against the incoming position the outgoing slide would drop its revealed steps. */
    state: DeckState;
    direction: TransitionDirection;
};
/** A change in flight: which slide is leaving, and what is carrying it out. */
export type SlideChange = {
    outgoing: OutgoingSlide;
    transition: Transition;
};
/**
 * Keep the slide being left behind on stage for the length of the transition.
 *
 * Which transition that is depends on both slides, so it is asked for rather than handed over: only here is the slide
 * the deck came from known.
 */
export declare function useSlideTransition(slide: number, state: DeckState, transitionBetween: (from: number, to: number) => Transition): SlideChange | null;
