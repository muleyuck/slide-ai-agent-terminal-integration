import type { ComponentPropsWithoutRef } from "react";
export type ColumnsProps = ComponentPropsWithoutRef<"div">;
/** Lay the columns it holds out side by side, sharing the width evenly. A wider one is set by the author on itself. */
export declare function Columns({ children, className, ...rest }: ColumnsProps): import("react").JSX.Element;
