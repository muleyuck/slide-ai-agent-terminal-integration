type ResizerProps = {
    width: number;
    onResize: (width: number) => void;
};
/** The edge between the list and the slide, and a handle to move it by. */
export declare function Resizer({ width, onResize }: ResizerProps): import("react").JSX.Element;
export {};
