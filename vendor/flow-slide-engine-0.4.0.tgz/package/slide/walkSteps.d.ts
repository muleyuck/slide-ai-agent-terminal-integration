import { type ReactNode } from "react";
export type WalkedSteps = {
    /** The markup with every step told which one it is. */
    children: ReactNode;
    stepCount: number;
};
/**
 * Number the steps in a slide's markup, in the order they are written.
 *
 * Read from the markup rather than registered by the steps themselves, so the count is settled during rendering and
 * never depends on the order effects run in. The cost is at both ends: a step hidden inside a component of the
 * author's own is invisible here and says so when it renders, and a step handed to a component that drops its children
 * is counted here but never appears. Whether children are rendered is not knowable until after the render this count
 * has to be ready for.
 */
export declare function walkSteps(children: ReactNode): WalkedSteps;
