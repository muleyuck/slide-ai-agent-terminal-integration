import { type DeckMode } from "../deck/mode";
/** Unlike `DeckPosition`, the step is a concrete index: only a resolved position can be written to the URL. */
export type HashState = {
    mode: DeckMode;
    slide: number;
    step: number;
};
/**
 * Read a `#/overview/3/2` hash into a mode and a 0-origin position.
 *
 * 1-origin in the URL, matching the slide numbers a presenter reads on screen. Anything unparseable falls back to the
 * first slide of present rather than throwing, and does so wholesale: a half-understood URL is a worse guess than the
 * beginning.
 */
export declare function parseHash(hash: string): HashState;
/** Write a mode and a 0-origin position as a `#/overview/3/2` hash. */
export declare function formatHash(state: HashState): string;
