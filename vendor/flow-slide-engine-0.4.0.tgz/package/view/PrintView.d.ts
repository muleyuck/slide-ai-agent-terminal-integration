import type { ViewProps } from "./ViewProps";
/**
 * The whole deck stacked for paper, one slide to a page.
 *
 * Every slide stands at its last step: `Step` only ever reveals, so a build needs no pages of its own.
 */
export declare function PrintView({ slides, width, height }: ViewProps): import("react").JSX.Element;
