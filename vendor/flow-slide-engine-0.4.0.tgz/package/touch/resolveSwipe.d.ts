/** Which way a swipe carries the deck. */
export type SwipeDirection = "forward" | "backward";
/** Where a gesture began and where it ended, which is the whole of what decides it. */
export type Swipe = {
    startX: number;
    startY: number;
    endX: number;
    endY: number;
};
/**
 * Read a gesture as a swipe, or null where it was something else.
 *
 * Coordinates alone: which pointer drew them, and whether the deck is in a mode that moves, belong to the caller.
 */
export declare function resolveSwipe({ startX, startY, endX, endY }: Swipe): SwipeDirection | null;
