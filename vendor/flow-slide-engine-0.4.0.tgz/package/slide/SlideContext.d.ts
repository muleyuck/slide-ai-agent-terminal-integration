/**
 * How far the slide on screen has been stepped through; a step is revealed once its index is below this.
 *
 * Null outside a `<Slide>`, so a stray `<Step>` can say so rather than silently never appearing.
 */
export declare const SlideContext: import("react").Context<number | null>;
