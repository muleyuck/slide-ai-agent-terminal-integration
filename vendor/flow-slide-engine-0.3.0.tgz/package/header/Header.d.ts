/**
 * The bar that names the deck's modes, and the keys that reach them.
 *
 * Drawn in every mode, print included: a deck opened straight into print would otherwise offer no way out but the URL.
 * Whether it is visible is the stylesheet's alone — the pointer reaching it is what brings it in.
 */
export declare function Header(): import("react").JSX.Element;
