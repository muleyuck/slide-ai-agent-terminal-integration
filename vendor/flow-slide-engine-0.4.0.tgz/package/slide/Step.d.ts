import { type ComponentPropsWithoutRef, type ElementType } from "react";
export type StepProps = ComponentPropsWithoutRef<"div"> & {
    /**
     * The element to render. Defaults to a div.
     *
     * A step inside a list has to be the list item itself: a wrapper between a list and its items is invalid markup and
     * breaks how the list is read out.
     */
    as?: ElementType;
};
/** One stage of a slide's reveal. Hidden steps keep their place, so nothing on screen shifts as the rest arrives. */
export declare function Step({ children, as: Element, className, ...rest }: StepProps): import("react").JSX.Element;
