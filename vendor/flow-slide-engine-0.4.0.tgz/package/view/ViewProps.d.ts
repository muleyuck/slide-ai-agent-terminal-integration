import type { ReactNode } from "react";
import type { Transition } from "../transition/types";
/** What every view of a deck is given. The state is not here: a view reads `DeckContext`, the same way a slide does. */
export type ViewProps = {
    slides: ReactNode[];
    width: number;
    height: number;
    transition: Transition;
};
