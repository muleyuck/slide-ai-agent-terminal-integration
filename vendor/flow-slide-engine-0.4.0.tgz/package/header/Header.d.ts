/**
 * The bar that names the deck's modes, and the keys that reach them.
 *
 * Drawn in every mode, print included: a deck opened straight into print would otherwise offer no way out but the URL.
 * Whether it is visible is the stylesheet's alone — a pointer or the focus reaching it is what brings it in, and where
 * there is no pointer to hover it simply stays.
 */
export declare function Header(): import("react").JSX.Element;
