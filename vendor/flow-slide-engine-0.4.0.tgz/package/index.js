import { Children as e, cloneElement as t, createContext as n, createElement as r, isValidElement as i, useCallback as a, useContext as o, useEffect as s, useLayoutEffect as c, useMemo as l, useReducer as u, useRef as d, useState as f } from "react";
import { jsx as p, jsxs as m } from "react/jsx-runtime";
//#region src/slide/resolveStep.ts
function h(e, t) {
	let n = Number.isFinite(t) ? Math.max(t, 0) : 0;
	return e === "last" ? n : Number.isFinite(e) ? Math.min(Math.max(e, 0), n) : 0;
}
//#endregion
//#region src/deck/DeckContext.ts
var g = n(null), _ = () => {};
//#endregion
//#region src/deck/resolveSlide.ts
function v(e, t) {
	return !Number.isFinite(e) || !Number.isFinite(t) ? 0 : Math.min(Math.max(e, 0), Math.max(t - 1, 0));
}
//#endregion
//#region src/deck/useDeck.ts
function y() {
	let e = o(g);
	if (e === null) throw Error("useDeck() was called outside a <Deck>. Render the component that calls it inside one.");
	let { state: t, slideCount: n, dispatch: r } = e;
	return l(() => ({
		mode: t.mode,
		setMode: (e) => r({
			type: "setMode",
			mode: e
		}),
		slide: v(t.position.slide, n),
		slideCount: n,
		step: h(t.position.step, t.stepCount),
		stepCount: t.stepCount,
		next: () => r({ type: "next" }),
		prev: () => r({ type: "prev" }),
		goTo: ({ slide: e, step: t = 0 }) => r({
			type: "goTo",
			position: {
				slide: e,
				step: t
			}
		})
	}), [
		t,
		n,
		r
	]);
}
//#endregion
//#region src/keyboard/keymap.ts
var b = /* @__PURE__ */ new Map([
	["ArrowRight", "next"],
	["ArrowDown", "next"],
	["PageDown", "next"],
	[" ", "next"],
	["Enter", "next"],
	["ArrowLeft", "prev"],
	["ArrowUp", "prev"],
	["PageUp", "prev"],
	["Backspace", "prev"],
	["Home", "first"],
	["End", "last"]
]), x = /* @__PURE__ */ new Map([
	["ArrowRight", "nextSlide"],
	["ArrowDown", "nextSlide"],
	["PageDown", "nextSlide"],
	[" ", "nextSlide"],
	["Enter", "nextSlide"],
	["ArrowLeft", "prevSlide"],
	["ArrowUp", "prevSlide"],
	["PageUp", "prevSlide"],
	["Backspace", "prevSlide"],
	["Home", "first"],
	["End", "last"]
]), S = /* @__PURE__ */ new Map([
	["present", "Escape"],
	["overview", "o"],
	["browse", "b"],
	["print", "p"]
]), C = new Map([...S].map(([e, t]) => [t, e])), w = /* @__PURE__ */ new Set([
	"INPUT",
	"TEXTAREA",
	"SELECT"
]), T = /* @__PURE__ */ new Set(["BUTTON", "SUMMARY"]), ee = /* @__PURE__ */ new Set(["A", "AREA"]), te = /* @__PURE__ */ new Set([" ", "Enter"]);
function ne(e, t) {
	if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey || re(e.target, e.key)) return null;
	let n = C.get(e.key);
	if (n !== void 0) return {
		type: "setMode",
		mode: n
	};
	let r = (t === "present" ? b : x).get(e.key);
	return r === void 0 ? null : { type: r };
}
function re(e, t) {
	return e instanceof HTMLElement ? w.has(e.tagName) || e.isContentEditable ? !0 : te.has(t) ? T.has(e.tagName) ? !0 : ee.has(e.tagName) && e.hasAttribute("href") : !1 : !1;
}
//#endregion
//#region src/header/Header.tsx
function ie() {
	let e = y();
	return /* @__PURE__ */ p("header", {
		className: "fs-header",
		children: [...S].map(([t, n]) => /* @__PURE__ */ m("button", {
			type: "button",
			className: "fs-header-mode",
			"aria-pressed": e.mode === t,
			onClick: () => e.setMode(t),
			children: [t, /* @__PURE__ */ p("kbd", {
				className: "fs-header-key",
				children: n.length === 1 ? n.toUpperCase() : n
			})]
		}, t))
	});
}
//#endregion
//#region src/keyboard/useKeyboardNavigation.ts
function E(e, t) {
	s(() => {
		let n = (n) => {
			let r = ne(n, t);
			r !== null && (n.preventDefault(), e(r));
		};
		return window.addEventListener("keydown", n), () => window.removeEventListener("keydown", n);
	}, [e, t]);
}
//#endregion
//#region src/touch/resolveSwipe.ts
var ae = 50;
function oe({ startX: e, startY: t, endX: n, endY: r }) {
	let i = n - e, a = r - t;
	return Math.abs(i) < ae || Math.abs(i) <= Math.abs(a) ? null : i < 0 ? "forward" : "backward";
}
//#endregion
//#region src/touch/useTouchNavigation.ts
var D = /* @__PURE__ */ new Set(["touch", "pen"]);
function O(e, t, n) {
	s(() => {
		let r = e.current;
		if (r === null || n !== "present") return;
		r.style.touchAction = "pan-y pinch-zoom";
		let i = null, a = (e) => {
			if (D.has(e.pointerType)) {
				if (!e.isPrimary) {
					i = null;
					return;
				}
				i = {
					pointerId: e.pointerId,
					startX: e.clientX,
					startY: e.clientY
				};
			}
		}, o = (e) => {
			if (i === null || i.pointerId !== e.pointerId) return;
			let n = {
				startX: i.startX,
				startY: i.startY,
				endX: e.clientX,
				endY: e.clientY
			};
			i = null;
			let r = oe(n);
			r !== null && t({ type: r === "forward" ? "next" : "prev" });
		}, s = () => {
			i = null;
		};
		return r.addEventListener("pointerdown", a), r.addEventListener("pointerup", o), r.addEventListener("pointercancel", s), () => {
			r.style.touchAction = "", r.removeEventListener("pointerdown", a), r.removeEventListener("pointerup", o), r.removeEventListener("pointercancel", s);
		};
	}, [
		e,
		t,
		n
	]);
}
//#endregion
//#region src/transition/presets.ts
var k = {
	forward: "none",
	backward: "none"
}, se = {
	durationMs: 0,
	enter: k,
	leave: k
}, A = {
	durationMs: 250,
	enter: {
		forward: "fs-fade-in",
		backward: "fs-fade-in"
	},
	leave: {
		forward: "fs-fade-out",
		backward: "fs-fade-out"
	}
}, ce = {
	durationMs: 300,
	enter: {
		forward: "fs-enter-from-right",
		backward: "fs-enter-from-left"
	},
	leave: {
		forward: "fs-leave-to-left",
		backward: "fs-leave-to-right"
	}
}, le = /* @__PURE__ */ new Set([
	"present",
	"overview",
	"browse",
	"print"
]);
function ue(e) {
	return e !== void 0 && le.has(e) ? e : null;
}
//#endregion
//#region src/url/hash.ts
var j = {
	mode: "present",
	slide: 0,
	step: 0
};
function de(e) {
	let t = e.startsWith("#") ? e.slice(1) : e;
	if (!t.startsWith("/")) return { ...j };
	let [n, r, i] = t.slice(1).split("/"), a = ue(n);
	if (a === null) return { ...j };
	if (r === void 0) return {
		mode: a,
		slide: 0,
		step: 0
	};
	let o = N(r);
	if (o === null) return { ...j };
	if (i === void 0) return {
		mode: a,
		slide: o,
		step: 0
	};
	let s = N(i);
	return s === null ? { ...j } : {
		mode: a,
		slide: o,
		step: s
	};
}
function M(e) {
	return `#/${e.mode}/${e.slide + 1}/${e.step + 1}`;
}
function N(e) {
	if (e === void 0 || !/^\d+$/.test(e)) return null;
	let t = Number(e);
	return t >= 1 ? t - 1 : null;
}
//#endregion
//#region src/url/useHashSync.ts
function P() {
	return de(window.location.hash);
}
function F({ enabled: e, mode: t, position: n, dispatch: r }) {
	let { slide: i, step: a } = n;
	s(() => {
		if (!e) return;
		let t = () => {
			let e = P();
			r({
				type: "setMode",
				mode: e.mode
			}), r({
				type: "goTo",
				position: {
					slide: e.slide,
					step: e.step
				}
			});
		};
		return window.addEventListener("hashchange", t), () => window.removeEventListener("hashchange", t);
	}, [e, r]), s(() => {
		if (!e) return;
		let n = M({
			mode: t,
			slide: i,
			step: a
		});
		n !== window.location.hash && window.history.replaceState(null, "", n);
	}, [
		e,
		t,
		i,
		a
	]);
}
function I(e) {
	return typeof e != "number" || !Number.isFinite(e) ? 240 : Math.min(Math.max(e, 120), 480);
}
//#endregion
//#region src/browse/Resizer.tsx
var L = 16;
function R({ width: e, onResize: t }) {
	let n = d(null);
	return /* @__PURE__ */ p("div", {
		className: "fs-resizer",
		role: "separator",
		"aria-orientation": "vertical",
		"aria-label": "Resize the slide list",
		"aria-valuenow": e,
		"aria-valuemin": 120,
		"aria-valuemax": 480,
		tabIndex: 0,
		onPointerDown: (t) => {
			n.current = {
				x: t.clientX,
				width: e
			}, t.currentTarget.setPointerCapture(t.pointerId);
		},
		onPointerMove: (e) => {
			let r = n.current;
			r !== null && t(r.width + (e.clientX - r.x));
		},
		onPointerUp: (e) => {
			n.current = null, e.currentTarget.releasePointerCapture(e.pointerId);
		},
		onKeyDown: (n) => {
			let r = n.key === "ArrowRight" ? L : n.key === "ArrowLeft" ? -16 : 0;
			r !== 0 && (n.stopPropagation(), n.preventDefault(), t(e + r));
		}
	});
}
//#endregion
//#region src/browse/useSidebarWidth.ts
var z = "flow-slide-engine:sidebar-width";
function B() {
	let [e, t] = f(V);
	return [e, a((e) => {
		let n = I(e);
		t(n);
		try {
			window.localStorage.setItem(z, String(n));
		} catch {}
	}, [])];
}
function V() {
	try {
		let e = window.localStorage.getItem(z);
		return e === null ? 240 : I(Number(e));
	} catch {
		return 240;
	}
}
//#endregion
//#region src/stage/computeScale.ts
function H(e, t) {
	return !U(e) || !U(t) ? 0 : Math.min(t.width / e.width, t.height / e.height);
}
function U(e) {
	return W(e.width) && W(e.height);
}
function W(e) {
	return Number.isFinite(e) && e > 0;
}
//#endregion
//#region src/stage/Stage.tsx
var fe = {
	width: 0,
	height: 0
};
function G({ width: e, height: t, children: n }) {
	let r = d(null), [i, a] = f(fe);
	c(() => {
		let e = r.current;
		if (e === null) return;
		let t = () => {
			let t = {
				width: e.clientWidth,
				height: e.clientHeight
			};
			a((e) => e.width === t.width && e.height === t.height ? e : t);
		};
		t();
		let n = new ResizeObserver(t);
		return n.observe(e), () => n.disconnect();
	}, []);
	let o = {
		width: e,
		height: t,
		"--fs-state-scale": H({
			width: e,
			height: t
		}, i)
	};
	return /* @__PURE__ */ p("div", {
		className: "fs-stage-frame",
		ref: r,
		children: /* @__PURE__ */ p("div", {
			className: "fs-stage",
			style: o,
			children: n
		})
	});
}
//#endregion
//#region src/thumbnail/SlideThumbnail.tsx
function pe({ slide: e, index: t, slideCount: n, mode: r, width: i, height: a, current: o, onSelect: s }) {
	let c = {
		state: {
			mode: r,
			position: {
				slide: t,
				step: "last"
			},
			stepCount: 0
		},
		slideCount: n,
		dispatch: _
	};
	return /* @__PURE__ */ m("button", {
		type: "button",
		className: "fs-thumbnail",
		"data-current": o,
		onClick: s,
		"aria-label": `Slide ${t + 1}`,
		children: [/* @__PURE__ */ p("span", {
			className: "fs-thumbnail-number",
			"aria-hidden": "true",
			children: t + 1
		}), /* @__PURE__ */ p("span", {
			className: "fs-thumbnail-frame",
			inert: !0,
			children: /* @__PURE__ */ p(g, {
				value: c,
				children: /* @__PURE__ */ p(G, {
					width: i,
					height: a,
					children: e
				})
			})
		})]
	});
}
//#endregion
//#region src/thumbnail/Thumbnails.tsx
function K({ slides: e, width: t, height: n, layout: r }) {
	let i = o(g);
	if (i === null) throw Error("<Thumbnails> was rendered outside a <Deck>.");
	let { state: a, slideCount: s, dispatch: c } = i, l = v(a.position.slide, s);
	return /* @__PURE__ */ p("div", {
		className: "fs-thumbnails",
		"data-layout": r,
		children: e.map((e, r) => /* @__PURE__ */ p(pe, {
			slide: e,
			index: r,
			slideCount: s,
			mode: a.mode,
			width: t,
			height: n,
			current: r === l,
			onSelect: () => {
				c({
					type: "goTo",
					position: {
						slide: r,
						step: 0
					}
				}), a.mode === "overview" && c({
					type: "setMode",
					mode: "present"
				});
			}
		}, r))
	});
}
//#endregion
//#region src/deck/Progress.tsx
function me() {
	let e = y(), t = e.slideCount - 1, n = { "--fs-state-progress": t > 0 ? e.slide / t : 0 };
	return /* @__PURE__ */ p("div", {
		className: "fs-progress",
		style: n,
		children: /* @__PURE__ */ p("div", { className: "fs-progress-fill" })
	});
}
//#endregion
//#region src/deck/SlideNumber.tsx
function he() {
	let e = y();
	return /* @__PURE__ */ m("footer", {
		className: "fs-slide-number",
		children: [
			e.slide + 1,
			" / ",
			e.slideCount
		]
	});
}
//#endregion
//#region src/transition/SlideLayer.tsx
function ge({ transition: e, phase: t, direction: n, children: r }) {
	let i = {
		"--fs-state-duration": `${e.durationMs}ms`,
		"--fs-state-animation": _e(e, t, n)
	};
	return /* @__PURE__ */ p("div", {
		className: "fs-layer",
		style: i,
		inert: t === "leave",
		"data-fs-phase": t,
		children: r
	});
}
function _e(e, t, n) {
	return t === "settled" ? "none" : e[t][n];
}
//#endregion
//#region src/transition/useSlideTransition.ts
function q(e, t, n) {
	let [r, i] = f(null), a = d({
		slide: e,
		state: t
	}), o = d(0);
	return c(() => {
		let t = a.current;
		if (t.slide === e) return;
		window.clearTimeout(o.current);
		let r = n(t.slide, e);
		if (r.durationMs <= 0) {
			i(null);
			return;
		}
		i({
			outgoing: {
				slide: t.slide,
				state: t.state,
				direction: e > t.slide ? "forward" : "backward"
			},
			transition: r
		}), o.current = window.setTimeout(() => i(null), r.durationMs);
	}, [e, n]), c(() => {
		a.current = {
			slide: e,
			state: t
		};
	}), s(() => () => window.clearTimeout(o.current), []), r;
}
//#endregion
//#region src/view/PresentView.tsx
function J({ slides: e, width: t, height: n, transition: r }) {
	let i = o(g);
	if (i === null) throw Error("<PresentView> was rendered outside a <Deck>.");
	let { state: s, slideCount: c } = i, u = v(s.position.slide, c), d = q(u, s, a((t, n) => ve(e[Math.max(t, n)]) ?? r, [e, r])), f = d?.outgoing ?? null, h = d?.transition ?? r, y = l(() => f === null ? null : {
		state: f.state,
		slideCount: c,
		dispatch: _
	}, [f, c]), b = f !== null && y !== null && f.slide !== u ? f : null, x = b === null || y === null ? [{
		slide: u,
		context: i,
		phase: "settled"
	}] : [{
		slide: b.slide,
		context: y,
		phase: "leave"
	}, {
		slide: u,
		context: i,
		phase: "enter"
	}];
	return /* @__PURE__ */ m(G, {
		width: t,
		height: n,
		children: [
			x.map((t) => /* @__PURE__ */ p(g, {
				value: t.context,
				children: /* @__PURE__ */ p(ge, {
					transition: h,
					phase: t.phase,
					direction: f?.direction ?? "forward",
					children: e[t.slide]
				})
			}, t.slide)),
			/* @__PURE__ */ p(me, {}),
			/* @__PURE__ */ p(he, {})
		]
	});
}
function ve(e) {
	return i(e) ? e.props.transition : void 0;
}
//#endregion
//#region src/view/BrowseView.tsx
function ye(e) {
	let [t, n] = B(), r = { "--fs-state-sidebar-width": `${t}px` };
	return /* @__PURE__ */ m("div", {
		className: "fs-browse",
		style: r,
		children: [
			/* @__PURE__ */ p("div", {
				className: "fs-browse-sidebar",
				children: /* @__PURE__ */ p(K, {
					slides: e.slides,
					width: e.width,
					height: e.height,
					layout: "column"
				})
			}),
			/* @__PURE__ */ p(R, {
				width: t,
				onResize: n
			}),
			/* @__PURE__ */ p("div", {
				className: "fs-browse-stage",
				children: /* @__PURE__ */ p(J, { ...e })
			})
		]
	});
}
//#endregion
//#region src/view/OverviewView.tsx
function be({ slides: e, width: t, height: n }) {
	return /* @__PURE__ */ p("div", {
		className: "fs-overview",
		children: /* @__PURE__ */ p(K, {
			slides: e,
			width: t,
			height: n,
			layout: "grid"
		})
	});
}
//#endregion
//#region src/print/usePageStyle.ts
function xe(e, t) {
	s(() => {
		let n = document.createElement("style");
		return n.setAttribute("data-fs-page", ""), n.textContent = `@page { size: ${e}px ${t}px; margin: 0 }`, document.head.append(n), () => n.remove();
	}, [e, t]);
}
//#endregion
//#region src/view/PrintView.tsx
function Se({ slides: e, width: t, height: n }) {
	let r = o(g);
	if (r === null) throw Error("<PrintView> was rendered outside a <Deck>.");
	let { slideCount: i, state: a } = r;
	return xe(t, n), /* @__PURE__ */ p("div", {
		className: "fs-print",
		children: e.map((e, r) => {
			let o = {
				state: {
					mode: a.mode,
					position: {
						slide: r,
						step: "last"
					},
					stepCount: 0
				},
				slideCount: i,
				dispatch: _
			};
			return /* @__PURE__ */ p("div", {
				className: "fs-print-page",
				style: {
					width: t,
					height: n
				},
				children: /* @__PURE__ */ p(g, {
					value: o,
					children: /* @__PURE__ */ p(G, {
						width: t,
						height: n,
						children: e
					})
				})
			}, r);
		})
	});
}
//#endregion
//#region src/deck/reducer.ts
function Ce(e, t, n) {
	let r = we(e, n);
	switch (t.type) {
		case "next": return Te(r, n);
		case "prev": return Ee(r);
		case "first": return Y(r, {
			slide: 0,
			step: 0
		}, n);
		case "last": return Y(r, {
			slide: n - 1,
			step: "last"
		}, n);
		case "goTo": return Y(r, t.position, n);
		case "setStepCount": return De(r, t.count);
		case "nextSlide": return Oe(r, n);
		case "prevSlide": return ke(r);
		case "setMode": return t.mode === r.mode ? r : {
			...r,
			mode: t.mode
		};
	}
}
function we(e, t) {
	let n = v(e.position.slide, t);
	return n === e.position.slide ? e : {
		...e,
		position: {
			...e.position,
			slide: n
		}
	};
}
function Te(e, t) {
	let n = h(e.position.step, e.stepCount);
	return n < e.stepCount ? {
		...e,
		position: {
			slide: e.position.slide,
			step: n + 1
		}
	} : e.position.slide < t - 1 ? {
		...e,
		position: {
			slide: e.position.slide + 1,
			step: 0
		},
		stepCount: 0
	} : e;
}
function Ee(e) {
	let t = h(e.position.step, e.stepCount);
	return t > 0 ? {
		...e,
		position: {
			slide: e.position.slide,
			step: t - 1
		}
	} : e.position.slide > 0 ? {
		...e,
		position: {
			slide: e.position.slide - 1,
			step: "last"
		},
		stepCount: 0
	} : e;
}
function Y(e, t, n) {
	let r = v(t.slide, n);
	if (r !== e.position.slide) return {
		...e,
		position: {
			slide: r,
			step: t.step
		},
		stepCount: 0
	};
	let i = typeof t.step == "number" ? h(t.step, e.stepCount) : t.step;
	return i === e.position.step ? e : {
		...e,
		position: {
			slide: r,
			step: i
		}
	};
}
function De(e, t) {
	let n = h(e.position.step, t);
	return t === e.stepCount && n === e.position.step ? e : {
		...e,
		stepCount: t,
		position: {
			slide: e.position.slide,
			step: n
		}
	};
}
function Oe(e, t) {
	return e.position.slide >= t - 1 ? e : {
		...e,
		position: {
			slide: e.position.slide + 1,
			step: 0
		},
		stepCount: 0
	};
}
function ke(e) {
	return e.position.slide <= 0 ? e : {
		...e,
		position: {
			slide: e.position.slide - 1,
			step: "last"
		},
		stepCount: 0
	};
}
//#endregion
//#region src/deck/Deck.tsx
var Ae = 1280, je = 720;
function Me({ children: t, width: n = Ae, height: r = je, url: i = !0, transition: o = A }) {
	let s = l(() => e.toArray(t), [t]), c = s.length, f = a((e, t) => Ce(e, t, c), [c]), [_, y] = u(f, i, Ne), b = v(_.position.slide, c), x = h(_.position.step, _.stepCount), S = d(null);
	E(y, _.mode), O(S, y, _.mode), F({
		enabled: i,
		mode: _.mode,
		position: {
			slide: b,
			step: x
		},
		dispatch: y
	});
	let C = l(() => ({
		state: _,
		slideCount: c,
		dispatch: y
	}), [_, c]), w = {
		slides: s,
		width: n,
		height: r,
		transition: o
	};
	return /* @__PURE__ */ p(g, {
		value: C,
		children: /* @__PURE__ */ m("div", {
			className: "fs-deck",
			ref: S,
			children: [
				_.mode === "overview" && /* @__PURE__ */ p(be, { ...w }),
				_.mode === "browse" && /* @__PURE__ */ p(ye, { ...w }),
				_.mode === "print" && /* @__PURE__ */ p(Se, { ...w }),
				_.mode === "present" && /* @__PURE__ */ p(J, { ...w }),
				/* @__PURE__ */ p(ie, {})
			]
		})
	});
}
function Ne(e) {
	if (!e) return {
		mode: "present",
		position: {
			slide: 0,
			step: 0
		},
		stepCount: 0
	};
	let { mode: t, slide: n, step: r } = P();
	return {
		mode: t,
		position: {
			slide: n,
			step: r
		},
		stepCount: 0
	};
}
//#endregion
//#region src/utils/classes.ts
function X(...e) {
	return e.filter((e) => e !== void 0 && e !== "").join(" ");
}
//#endregion
//#region src/layout/Column.tsx
function Pe({ children: e, className: t, ...n }) {
	return /* @__PURE__ */ p("div", {
		...n,
		className: X("fs-column", t),
		children: e
	});
}
//#endregion
//#region src/layout/Columns.tsx
function Fe({ children: e, className: t, ...n }) {
	return /* @__PURE__ */ p("div", {
		...n,
		className: X("fs-columns", t),
		children: e
	});
}
//#endregion
//#region src/layout/Title.tsx
function Ie({ children: e, className: t, ...n }) {
	return /* @__PURE__ */ p("h1", {
		...n,
		className: X("fs-title", t),
		children: e
	});
}
//#endregion
//#region src/slide/SlideContext.ts
var Z = n(null), Q = n(null);
//#endregion
//#region src/slide/Step.tsx
function $({ children: e, as: t = "div", className: n, ...r }) {
	let i = o(Z), a = o(Q);
	if (i === null) throw Error("<Step> was rendered outside a <Slide>. Move it inside one.");
	if (a === null) throw Error("<Step> was not found by its slide. Write it directly in the slide's markup rather than inside a component of your own.");
	let s = a < i;
	return /* @__PURE__ */ p(t, {
		...r,
		className: X("fs-step", n),
		"data-revealed": s,
		"aria-hidden": !s,
		children: e
	});
}
//#endregion
//#region src/slide/walkSteps.ts
function Le(n) {
	let a = 0, o = (n) => {
		if (!i(n)) return n;
		if (n.type === $) {
			let e = a;
			return a += 1, r(Q, { value: e }, n);
		}
		let { children: s } = n.props;
		return s === void 0 || typeof s == "function" ? n : t(n, { children: e.map(s, o) });
	};
	return {
		children: e.map(n, o),
		stepCount: a
	};
}
//#endregion
//#region src/slide/Slide.tsx
function Re({ children: e, className: t, transition: n, ...r }) {
	let i = o(g);
	if (i === null) throw Error("<Slide> was rendered outside a <Deck>. Move it inside one.");
	let { state: a, dispatch: s } = i, { children: u, stepCount: d } = l(() => Le(e), [e]);
	c(() => {
		s({
			type: "setStepCount",
			count: d
		});
	}, [d, s]);
	let f = h(a.position.step, d);
	return /* @__PURE__ */ p(Z, {
		value: f,
		children: /* @__PURE__ */ p("div", {
			...r,
			className: X("fs-slide", t),
			children: u
		})
	});
}
//#endregion
export { Pe as Column, Fe as Columns, Me as Deck, Re as Slide, $ as Step, Ie as Title, A as fade, se as none, ce as slideHorizontal, y as useDeck };
