import type { ComponentPropsWithoutRef } from "react";
export type ColumnProps = ComponentPropsWithoutRef<"div">;
/** One column of a `<Columns>`. */
export declare function Column({ children, className, ...rest }: ColumnProps): import("react").JSX.Element;
