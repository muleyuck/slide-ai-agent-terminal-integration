import type { DeckMode } from "../deck/mode";
import type { DeckAction } from "../deck/reducer";
/** The parts of a `KeyboardEvent` that a binding decision depends on. */
export type KeyboardEventLike = {
    key: string;
    altKey: boolean;
    ctrlKey: boolean;
    metaKey: boolean;
    shiftKey: boolean;
    target: EventTarget | null;
};
type NavigationAction = Extract<DeckAction, {
    type: "next" | "prev" | "nextSlide" | "prevSlide" | "first" | "last";
}>;
export type KeyAction = NavigationAction | Extract<DeckAction, {
    type: "setMode";
}>;
/** The key that opens each mode, in the order a bar of them is offered. Also read by the header, so what it names and
    what the keyboard does cannot drift apart. */
export declare const MODE_KEYS: Map<DeckMode, string>;
/**
 * Translate a key press into an action, or null to let it through.
 *
 * Modified presses belong to the browser or the OS; a press the focused element acts on belongs to that element.
 */
export declare function keymap(event: KeyboardEventLike, mode: DeckMode): KeyAction | null;
export {};
