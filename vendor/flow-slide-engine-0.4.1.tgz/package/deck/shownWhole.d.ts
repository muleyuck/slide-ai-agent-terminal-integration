import { type DeckContextValue } from "./DeckContext";
import type { DeckMode } from "./mode";
import type { DeckPosition } from "./reducer";
/**
 * Where a slide shown whole stands.
 *
 * Every mode but `present` shows a slide whole — a thumbnail, a printed page, and the stage beside browse's list — so
 * none of them reads the step the deck is on. `"last"` rather than a count: the slide resolves the sentinel against its
 * own markup, so nothing outside it has to know how many steps it holds.
 */
export declare function wholePosition(slide: number): DeckPosition;
/**
 * The context one slide is shown under rather than driven by: whole, and reporting nothing back to the deck around it.
 *
 * Encloses only the slide, so its `setStepCount` lands on the no-op dispatch instead of reaching the running deck.
 */
export declare function shownWhole(mode: DeckMode, slide: number, slideCount: number): DeckContextValue;
