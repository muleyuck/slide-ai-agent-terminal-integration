import { type ReactNode } from "react";
type ThumbnailsProps = {
    slides: ReactNode[];
    width: number;
    height: number;
    /** A grid fills the overview; a single column runs down the side of browse. */
    layout: "grid" | "column";
};
/** Every slide at once, and the only place a thumbnail can move the deck from. */
export declare function Thumbnails({ slides, width, height, layout }: ThumbnailsProps): import("react").JSX.Element;
export {};
